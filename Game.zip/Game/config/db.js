// DB.js

module.exports = {
   DB: 'mongodb://localhost:27017/angular6crud'
};