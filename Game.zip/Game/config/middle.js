const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
try{
    const token = req.headers.authorization.split(" ")[1];
    jwt.verify(token, "secret");
    let jwtObject = jwt.decode(token);
    req.userdata = {username : jwtObject.username, userId: jwtObject.userId}
    let current = Date.now();
    if (current > jwtObject.exp) {
      next();
    }else {
      let exception = new Exception(ErrorCode.AUTHENTICATION.TOKEN_EXPIRE, MessageInfo.MI_TOKEN_EXPIRED, false);
      exception.httpStatus = HttpStatus.BAD_REQUEST;
      next(exception);
      }
    }
    catch (error) {
    res.status(401).json({ 
      message: "You are not authenticated!",
      status : 401
    });
  } 
}


