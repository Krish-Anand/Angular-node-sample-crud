class InvestmentNovel {
	name = 'InvestmentNovel';
	job = 'Teaching';
	goal = 'Try to teach everyone in almost every field';
}