const mongoose = require('mongoose');
const Product = require('../models/product')
const Schema = mongoose.Schema;
ObjectId = Schema.Types;

let Game = new Schema({
   user: 
  {
      type: String,
      ref:"User"
   },
   product:[{
     type:String, 
     ref: "Product",
     require:false
   }],
   gameNumber :{
      type:String,
   },
  name: {
    type: String
  },
  price: {
    type: Number
  }
});
Game.set('toJSON', { virtuals: true });
module.exports = mongoose.model('Game', Game);