const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userschema = new Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    firstname: { type: String, required: true },
    lastname: { type: String, required: true },
    phonenumber : {type : String, required : true},
    createdDate: { type: Date, default: Date.now },
    otp: {type: String},
    token:{type: String},
});

userschema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('User', userschema);