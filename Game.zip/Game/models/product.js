const mongoose = require('mongoose');
const Schema = mongoose.Schema;
ObjectId = Schema.Types;

let Product = new Schema({
   game: {
    type: String,
    ref:"Game"
   },
   productName: {
    type: String,
  },
   productPrice: {
    type: Number
  }
});
Product.set('toJSON', { virtuals: true });
module.exports = mongoose.model('Product', Product);
