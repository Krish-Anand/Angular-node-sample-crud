const express = require('express');
const productRoutes = express.Router();
const auth = require('../config/middle')

let Game = require('../models/Game');
let Product = require('../models/product')


productRoutes.route('/addproduct/:id').post(auth, function(req, res, next) {
  let id = req.params.id
  Game.findById({id}, function(err,game){
   if(game)
   console.log(game)
      const product = new Product({
       game: req.params.id,
       productName : req.body.productName,
       productPrice : req.body.productPrice,
    })
     product.save().then(() =>{
         const result ={
           status : 200,
           message : 'succesfully added'
         }
         res.send(result);
     })
    })
})
// productRoutes.route('/getproduct/:id').get( auth,function(req, res, next){
//   let id = req.params.id;
//   console.log(id)
//     const product = Product.find({game: id})
//       product.populate('game').exec((err, product) => {
//         if (err) return next(err);
//         console.log(product)
//           res.json({product})     
//          });
// })

module.exports = productRoutes;