const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const auth = require('../config/middle');
const OTP = require('otp-generator');

const userRoutes = express.Router();

let User = require('../models/User');

userRoutes.route('/register').post(function(req, res, next) {
    bcrypt.hash(req.body.password, 10)
    .then(hash => {
        const user = new User({
            username : req.body.username,
            firstname : req.body.firstname,
            lastname : req.body.lastname,
            phonenumber : req.body.phonenumber,
            image : req.body.imagePath,
            password : hash
        });
        user.save().then(() =>{
            const result ={
              status : 200,
              message : 'succesfully added'
            }
            res.send(result)
           
        })
        .catch(err => {
            const error ={
              status:402,
              message: err.message
            }
            res.send(error)   
        })

    })
   
})

userRoutes.route('/login').post((req, res ) => {
  let fetchedUser;
  User.findOne({username: req.body.username })
    .then(user => {
      if (!user) {
        return res.status(401).json({
          message: "Authentication failed"
        });
      }
      fetchedUser = user;
      return  bcrypt.compare(req.body.password, user.password);
    })
    .then(result => {
      if (!result) {
        return res.status(401).json({
          message: " failed"
        });  
      }
      const token = jwt.sign(
        { username: fetchedUser.username, userId: fetchedUser._id },
        "secret",
        { expiresIn: "1h"},
      )
      res.status(200).json({
        token: token,
        expiresIn: 3600,
        user : {'firstname':fetchedUser.firstname, 'lastname':fetchedUser.lastname, 'username':fetchedUser.username, 'phonenumber' : fetchedUser.phonenumber, 'id':fetchedUser._id, 'createdAt' : fetchedUser.createdDate}
      })
    })
    .catch(err => {
      return res.status(401).json({
        message: "Auth failes"
      });
    });
});
userRoutes.route('/forgotPassword').post((req, res, next) => {
  User.findOne({username: req.body.username} , function(err, user) {
  if(user){
    const otp = OTP.generate(6, { upperCase: false, specialChars: false, alphabets: false });
    user.otp = otp;
    user.save({}).then( checkedotp => {
      if(checkedotp) {
        console.log(otp);
        res.send("item saved to database");
      } else {
        res.json({
          message: 'otp is not saved'
        })
      }
    })
  } else {
    const errorcode = {
      status: 401,
      message: 'username not found'
    }
    res.json({
      message: errorcode
    })
  }
})
}, (err) => {
  res.json({
    message: 'username null'
  })
})

userRoutes.route('/resetPassword').post((req, res, next) => {
  User.findOne({otp : req.body.otp}, function(otp, err) {
  if(otp) {
    
  } else {
     user.find({password: req.body.password})
  }
})
})


userRoutes.route('/logout').get((req, res, next) => {
   res.json({
     status : 200,
     message : "session logout successfully"
   })   
});

module.exports = userRoutes;
