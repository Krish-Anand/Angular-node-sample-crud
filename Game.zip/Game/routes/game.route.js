const express = require('express');
const gameRoutes = express.Router();
const auth = require('../config/middle')

let Game = require('../models/Game');
let Product = require('../models/product');


gameRoutes.route('/add').post( auth, function (req, res) {
  let game = new Game({
    name : req.body.name,
    price : req.body.price,
    gameNumber : req.body.gameNumber,
    user : req.userdata.userId
  })
   game.save()
    .then(game => {
    res.status(200).json({'game': 'CoGamein added successfully'});
    })
    .catch(err => {
    res.status(400).send("unable to save to database");
    });
});

gameRoutes.route('/edit/:id').get(auth, function (req, res) {
  let id = req.params.id;
  Game.findById(id, function (err, game){
      res.json(game);
  });
});

gameRoutes.route('/update/:id').post(auth, function (req, res) {
   Game.findById(req.params.id, req.userdata.userId, function(err, game) {
    if (!game)
      return next(new Error('Could not load Document'));
    else {
      game.name = req.body.name;
      game.price = req.body.price;
      game.save().then(game => {
          res.json("update success");
      })
      .catch(err => {
            res.status(400).send("unable to update the database");
      });
    }
  });
});

gameRoutes.route('/delete/:id').delete( auth, function (req, res) {
   Game.findByIdAndRemove({_id: req.params.id ,  user : req.userdata.userId}, function(err, game){
        if(err) res.json(err);
        else res.json('Successfully removed');
    });
});

gameRoutes.route('/gamepage').get(auth, function (req, res, next) {
        var query;
        var perPage = req.query.perPage || 2
        var page = req.query.page || 1
        var name = req.query.name 
        var user = req.userdata.userId
        var game = Game.find({user:user})
        if(name)
          query={'name':{$regex : '.*'+name+'.*'}}
           else {
            query = {};
           }
           game.find(query)
            .exec(function(err, games){
                if(err) return next(err)
                else
                {
                game.count().exec(function(err, count){
                    if (err) return next(err)
                    console.log(count);
                    games.forEach(element => {
                      Product.find({game: element._id}).exec((err,product)=>{
                       element.product=product   
                       console.log(element.product);
                    })
                  });
                  setTimeout(() => {
                    res.json({
                           games: games,
                           current: page,
                           pages: Math.ceil(count / perPage),
                           total: Math.ceil(count)
                       })
                 }, 100);
                })
            }
            })
        })

module.exports = gameRoutes;