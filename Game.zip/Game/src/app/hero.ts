export class Hero {
    name: string;
  }
