export interface Product {
    game: String;
    productName: String;
    productPrice:  Number; 
  }