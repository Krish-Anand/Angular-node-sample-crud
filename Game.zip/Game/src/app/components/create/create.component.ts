import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { GameService } from '../../game.service';
import {ToastrService} from 'ngx-toastr';
import {Router, ActivatedRoute } from '@angular/router';
import {map} from 'rxjs/operators';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  temprory: String ;
  title = 'Add Game';
  addForm: FormGroup;
  add: any = {};
  submitted: Boolean = false;
  constructor(private gameservice: GameService, private fb: FormBuilder,  private router: Router, private toastr: ToastrService) {
   }

  AddGame() {
    this.submitted = true;
    const obj = {
      gameNumber : this.add.gameNumber,
      name : this.add.name,
      price : this.add.price
    };
    if (obj.gameNumber && obj.name && obj.price && this.submitted) {
      this.gameservice.addGame(obj).subscribe((response) => {
       if (response) {
       console.log(response);
        this.router.navigate(['/index']);
       }
      },
      (error) => {
        console.log(error);
      });
    }
 }
  ngOnInit() {
    this.addForm = this.fb.group({
      name : ['', Validators.required],
     price: ['', Validators.required]
     });
  }

  // addnew() {
  //   this.submitted = true;
  //   const obj = {
  //     gameNumber : this.add.gameNumber,
  //     name : this.add.name,
  //     price : this.add.price
  //   };
  //   if (obj.gameNumber && obj.name && obj.price) {
  //      localStorage.setItem('gamevalue', JSON.stringify(obj));
  //      this.router.navigate(['/index']);
  //   }
  // }
}
