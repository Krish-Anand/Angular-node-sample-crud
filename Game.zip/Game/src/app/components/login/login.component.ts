import { Component, OnInit, TemplateRef } from '@angular/core';
import {UserService} from '../../user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { map } from 'rxjs/operators';
import {Router, ActivatedRoute } from '@angular/router';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  modalRef: BsModalRef;
   loginForm: FormGroup;
   submitted: Boolean = false;
   auth: any = {};
   private token: string;
  constructor( private formBuilder: FormBuilder,
    private userService: UserService,
    private modalService: BsModalService,
    private route: ActivatedRoute,
    private router: Router) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
     username : ['', Validators.required],
     password: ['', Validators.required]
    });
  }

  onSubmit() {
    this.submitted = true;
    const valid = {
      username : this.auth.username,
      password : this.auth.password
    };
    console.log(valid);
    if (valid.username  &&  valid.password  &&  this.submitted) {
      this.userService.login(valid).pipe(map(user => {
        console.log(user);
        if (user && user.token) {
          localStorage.setItem('userToken', JSON.stringify(user.token));
          localStorage.setItem('currentUser', JSON.stringify(user));
        }
        return user;
      }))
      .subscribe(
          data => {
           const token = data.token;
           this.token = token;
           if (token) {
           this.router.navigate(['/index']);
           }
          }
      ); }
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
}
