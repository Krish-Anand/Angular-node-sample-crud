import { Component, OnInit, createPlatformFactory } from '@angular/core';
import {UserService} from '../../user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

    registerForm: FormGroup;
    loading = false;
    submitted = false;
    Signup: any = {};
    submit: Boolean = false;
    constructor(
        private formBuilder: FormBuilder,
        private userService: UserService,
      ) { }

    ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      username: ['', Validators.required],
      phonenumber: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]] ,
      confirmpassword : ['', [Validators.required, Validators.minLength(6)]]
  });
  }
    submitdata() {
       this.submit = true;
       const obj = {
         firstname : this.Signup.firstname,
         lastname : this.Signup.lastname,
         username : this.Signup.username,
         phonenumber : this.Signup.phonenumber,
         password : this.Signup.password,
         confirmpassword  : this.Signup.confirmpassword,
       };
       if (obj.password === obj.confirmpassword) {
         delete obj.confirmpassword;
        this.userService.register(obj);
       }
      }
     }
