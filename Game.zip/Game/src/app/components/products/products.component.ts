import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router, ActivatedRoute } from '@angular/router';
import {GameService} from '../../game.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  productForm: FormGroup;
  submitted: Boolean = false;
  product: any = {};
constructor(private route: ActivatedRoute, private formBuilder: FormBuilder, private router: Router, private gameservice: GameService) { }
  addProduct() {
  this.submitted = true;
  const add = {
    productName : this.product.productName,
    productPrice : this.product.productPrice
  };
if (add.productName && add.productPrice && this.submitted) {
  this.route.params.subscribe(params => {
    this.gameservice.addproduct(params['id'], add).subscribe((response) => {
        if (response) {
          this.router.navigate(['/index']);
        }
    });
  });
}
  }
  ngOnInit() {
    this.productForm = this.formBuilder.group({
      productName: ['', Validators.required],
      productPrice: ['', Validators.required]
     });
  }
}
