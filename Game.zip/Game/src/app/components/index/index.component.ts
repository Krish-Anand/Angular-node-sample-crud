import { Component, OnInit } from '@angular/core';
import { GameService, } from '../../game.service';
import {ToastrService} from 'ngx-toastr';
import {UserService} from '../../user.service';
import { Router } from '@angular/router';
import {Product} from '../../Product';
import { Hero } from '../../hero';
import { HEROES } from '../../mock-heroes';
import {startsWithPipe} from '../../customstart.pipes';
import * as _ from 'lodash';
import { Chart } from 'angular-highcharts';
import {IMyDpOptions} from 'mydatepicker';
declare let Strophe: any;
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css'],
})

export class IndexComponent implements OnInit {
  hari: any;
  chartname: any;
  chartvalue: any;
  chart: any;
  naming: Boolean = false;
  pricing: Boolean = false;
  path: string[] = [];
  order: any = 1; // 1 asc, -1 desc;
  public show_dialog ;
  selectedHero: String = '';
  dropdownlist = '';
  heroes = HEROES;
  selected: Hero;
  isCollapsed = false;
  product: Product[] = [];
  pageNumber: Number = 1 ;
  search = '';
  games: any = [];
  searchtext = '';
  perPage: Number =  5;
  total = 0;
  users: any = {};
  selectedId: any = false;
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd.mm.yyyy',
};
public model: any = { date: { year: 2018, month: 10, day: 9 } };
   constructor(private gameservice: GameService, private toastr: ToastrService, private userservice: UserService, private router: Router) {}
    ngOnInit() {
     this.users = this.gameservice.getusername();
     this.getGames(this.pageNumber);
    }
  getGames(value) {
    this.pageNumber = value;
    this.show_dialog = -1;
    this.gameservice.getGames(this.searchtext, this.pageNumber)
    .subscribe((data: any)  => {
      this.total = data.total;
      this.games = data.games;
  });
  }
  deleteGame(id) {
      this.gameservice.onDelete(id).subscribe(games => this.getGames('value'));
   }
  //  getList(id){
  //    this.selectedId = true;
  //    this.gameservice.getproduct(id).subscribe((values:any) => {
  //    {this.product = values.product})
  //  }
   onSelect(hero: Hero): void {
    this.selected = hero;
  }
  toggle(i) {
    this.show_dialog = i;
  }
// sortColumn(games: any) {
// if (this.sortBy = _.sortBy( this.games,name)) {
//   games.direction= games.direction === 'asc' ? 'desc' : 'asc';
//   console.log(games.name)
// }
// else{
// this.sortBy = _.sortBy( this.games,name).reverse()
// console.log(this.sortBy)
// }
// }
sortTable(game: string) {
  this.naming = !this.naming;
  this.pricing = !this.pricing;
  this.path = game.split('.');
  console.log(this.path);
  this.order = this.order * (-1);
}
chartdomain() {
  console.log(this.games);
  this.chartname = [];
  this.chartvalue = [];
  this.games.forEach(element => {
    this.chartvalue.push(element.price);
    this.chartname.push(element.name);
  });
  this.chart = new Chart({
    chart: {
      type: 'bar'
    },
    title: {
      text: 'Game Users Linechart'
    },
    credits: {
      enabled: true
    },
    xAxis: {
      categories: this.chartname
  },
  plotOptions: {
    column: {
        borderRadius: 10
    },
},
colors: ['#f17a8f', '#191970'],
    series: [
      {
        name: 'GAME PRICE',
        data: this.chartvalue,
      },
      {
        name: 'GAME VALUE',
        data: [1000, 2000, 2000, 3000, 4000, 5000]
      }
    ],
    responsive: {
      rules: [{
          condition: {
              maxWidth: 50
          },
          chartOptions: {
              legend: {
                  align: 'center',
                  verticalAlign: 'bottom',
                  layout: 'vertical'
              }
          }
      }]
  }
  });
}
}
