import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgxPaginationModule} from 'ngx-pagination';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {Injectable, Injector} from '@angular/core';
import { MyDatePickerModule } from 'mydatepicker';
import {ToastrModule} from 'ngx-toastr';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { SortingCompaniesPipe } from './sort';
import { ChartModule } from 'angular-highcharts';



import { AppComponent } from './app.component';
import { CreateComponent } from './components/create/create.component';
import { EditComponent } from './components/edit/edit.component';
import { IndexComponent } from './components/index/index.component';
import { JwtInterceptor} from './jwt.interceptor';

import {Routing} from './app.routing';

import { GameService } from './game.service';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { UserService } from './user.service';
import { HeaderComponent } from './header/header.component';
import { ProductsComponent } from './components/products/products.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ExponentialStrengthPipe } from './exponential-strength.pipes';
import {startsWithPipe} from './customstart.pipes';
import { PopoverModule } from 'ngx-bootstrap/popover';
import {Strophe} from 'strophe';




@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    EditComponent,
    IndexComponent,
    LoginComponent,
    SignupComponent,
    HeaderComponent,
    ProductsComponent,
    ExponentialStrengthPipe, startsWithPipe,
    SortingCompaniesPipe,
  ],

  imports: [
    BrowserModule,
    ToastrModule.forRoot(),
    Routing,
    NgxPaginationModule,
    HttpClientModule,
    FormsModule, ReactiveFormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot(),
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    SelectDropDownModule,
    ChartModule,
    MyDatePickerModule,
    PopoverModule.forRoot(),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    GameService, UserService, SortingCompaniesPipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
