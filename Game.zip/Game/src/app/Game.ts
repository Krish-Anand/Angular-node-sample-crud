export interface Game {
    id?: Number;
    name: String;
    price: Number;
    user: String;
  }
