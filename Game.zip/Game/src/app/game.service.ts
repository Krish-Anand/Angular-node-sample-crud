import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { DemoService } from './demo.service';

@Injectable({
  providedIn: 'root'
})
export class GameService {
tempvariable: String;
users: any = {};
uri: String = 'http://localhost:4000/games';
url: String = 'http://localhost:4000/product';

constructor(private http: HttpClient , private router: Router, private demoservice: DemoService ) {}

addGame(obj): Observable<any> {
  return this.http.post(`${this.uri}/add`, obj).pipe(
    catchError(error => {
      return this.handleError(error);
              })
              );
}

getGames(name, page): Observable<any> {
  return this.http.get(`${this.uri}/gamepage?name=${name}&page=${page}`).pipe(
    catchError(error => {
      return this.handleError(error);
             })
             );
}

editGame(id) {
  return this.http.get(`${this.uri}/edit/${id}`);
}

updateGame(name, price, id) {
    const obj = {
          name: name,
          price: price
                };
  return this.http.post(`${this.uri}/update/${id}`, obj);
}

onDelete(id) {
  return this.http.delete(`${this.uri}/delete/${id}`);
}

addproduct(id , add) {
  return this.http.post(`${this.url}/addproduct/${id}`, add).pipe(
    catchError(error => {
         return this.handleError(error);
            })
       );
}

getusername() {
  return	this.demoservice.getuser();
}

handleError(error: Response) {
  if (error.status === 401) {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userToken');
    this.router.navigate(['/login']);
    return throwError(error);
  } else {
      return throwError(error);
         }
}
}
