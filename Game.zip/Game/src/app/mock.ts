// tslint:disable-next-line:class-name
export interface fakelist {
    user: string;
  }
