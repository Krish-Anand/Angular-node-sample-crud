import { Hero } from './hero';

export const HEROES: Hero[] = [
  {  name: 'playstation' },
  {  name: 'videogames' },
  {  name: 'Indoor' },
  {  name: 'Outdoor' },
  {  name: 'vision' }
];
