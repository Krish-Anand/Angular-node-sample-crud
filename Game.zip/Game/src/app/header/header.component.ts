import { Component, OnInit, TemplateRef } from '@angular/core';
import {UserService} from '../user.service';
import { Router } from '@angular/router';
import {ToastrService} from 'ngx-toastr';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  donutchart = new Chart({
    chart: {
        type: 'pie'
  },
  title: {
      text: 'Game Users'
  },
  tooltip: {
      pointFormat: '<span style="color:{point.color}">\u25CF</span> <b> {point.name}</b><br/>' +
          'Area (square km): <b>{point.y}</b><br/>',
  },
  plotOptions: {
    pie: {
        cursor: 'pointer',
        dataLabels: {
            enabled: false
        },
        showInLegend: true
    }
},
  series: [{
      innerSize: '90%',
      name: 'countries',
      data: [{
          name: 'India',
          y: 59,
      }, {
          name: 'France',
          y: 55,
      },  {
          name: 'Czech ',
          y: 58,
      }]
  }],
  // tslint:disable-next-line:semicolon
  })
  // add point to chart serie
  add() {
    this.donutchart.addPoint(Math.floor(Math.random() * 10));
  }
  // tslint:disable-next-line:member-ordering
  modalRef: BsModalRef;
   // tslint:disable-next-line:member-ordering
   users: any = {};
   // tslint:disable-next-line:member-ordering
   userId: String;
    // tslint:disable-next-line:max-line-length
    constructor(private userservice: UserService, private modalService: BsModalService, private router: Router, private toastr: ToastrService) { }
  ngOnInit() {
    this.users = JSON.parse(localStorage.getItem('currentUser')).user.firstname;
}
  onLogout(template: TemplateRef<any>) {
    this.userservice.logout().subscribe((response) => {
      if (response) {
      localStorage.removeItem('currentUser');
      localStorage.removeItem('userToken');
      this.router.navigate(['/login']);
      this.modalRef = this.modalService.show(template);
      }
    },
    (error) => {
      console.log(error);
    });
  }
  }


// export class Demo {
//    static users: any;
//    static SumValue(): any {
//     this.users = JSON.parse(localStorage.getItem('currentUser')).user.firstname;
//     return this.users;
// }
// }
