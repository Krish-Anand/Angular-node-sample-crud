import { RouterModule, Routes } from '@angular/router';
import { CreateComponent } from './components/create/create.component';
import { EditComponent } from './components/edit/edit.component';
import { IndexComponent } from './components/index/index.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { ProductsComponent } from './components/products/products.component';
const routes: Routes = [
  {
    path : '',
    component : SignupComponent
  },
    {
      path: 'create',
      component: CreateComponent
    },
    {
      path: 'edit/:id',
      component: EditComponent
    },
    {
      path: 'index',
      component: IndexComponent
    },
    {
      path: 'signup',
      component: SignupComponent
    },
    {
      path: 'login',
      component: LoginComponent
    },
    {
      path: 'product/addproduct/:id',
      component: ProductsComponent
    }
  ];

export let Routing = RouterModule.forRoot(routes);
