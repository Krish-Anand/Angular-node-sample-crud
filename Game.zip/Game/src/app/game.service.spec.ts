import { TestBed, inject } from '@angular/core/testing';

import { GameService } from './game.service';

describe('GameserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GameService]
    });
  });

  it('should be created', inject([GameService], (service: GameService) => {
    expect(service).toBeTruthy();
  }));
});
