export interface User{
    id? : Number,
    username : String,
    password : String,
    firstname : String,
    lastname : String,
    phonenumber : Number,
    token : String
}