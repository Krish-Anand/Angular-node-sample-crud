const express = require('express'),
	bodyParser = require('body-parser'),
	cors = require('cors'),
	mongoose = require('mongoose'),
	config = require('./config/db');

const gameRoutes = require('./routes/game.route');
const userRoutes = require('./routes/user.route');
const productRoutes = require('./routes/product.route');

	mongoose.Promise = global.Promise;
	mongoose.connect(config.DB).then(
	  () => {console.log('Database is connected') },
	  err => { console.log('Can not connect to the database'+ err)}
	);

const app = express();
	app.use(bodyParser.json());
	app.use(cors());
	app.use((err,req, res, next) => {
		res.setHeader("Access-Control-Allow-Origin", "*");
		res.setHeader(
		  "Access-Control-Allow-Headers",
		  "Origin, X-Requested-With, Content-Type, Accept, Authorization"
		);
		res.setHeader(
		  "Access-Control-Allow-Methods",
		  "GET, POST, PATCH, PUT, DELETE, OPTIONS"
		);
	
		next();
	  });
	app.use('/games', gameRoutes);
	app.use('/users', userRoutes);
	app.use('/product', productRoutes);


const port = process.env.PORT || 4000;

const server = app.listen(port, function(){
	console.log('Listening on port ' + port);
});